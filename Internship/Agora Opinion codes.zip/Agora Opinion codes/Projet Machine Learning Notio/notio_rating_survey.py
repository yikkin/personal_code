# -*- coding: utf-8 -*-
"""
Created on Fri Sep 22 16:49:01 2017

@author: Utilisateur
"""
#importation des modules
#module de connexion à la base de données localement sur le pc
#lors du plug sur la BDD de production à mettre en commentaires 
#et plug la BDD par un connecteur adéquat (voir internet)
import sqlite3 as sql
from datetime import datetime, timedelta
from dateutil import parser

import uuid
import math as m

#ouverture et connexion à la base de données
conn = sql.connect('db_alg_gpcc.db')
cur = conn.cursor()

#fonction de rating
def rate(x,y):
    reslt = abs(1 - (1/(m.sqrt(x + y)**2 - 1)))
    return reslt


def ratings(id_question):
    
    #verifiaction si on possède des votes dans la table nao_votes pour la question qu'on s apprete à noter
    request = cur.execute("select nc.id_device , nc.from_begin_campaign , (sum(nv.yes) + sum(nv.neutre) + sum(nv.no)) , np.nb_votes_treshold , round((sum(nv.yes) + 0.5*sum(nv.neutre))/(sum(nv.yes) + sum(nv.neutre) + sum(nv.no)) , 2) , nq.treshold from nao_campaign as nc , nao_question_bank as nq , nao_votes as nv , nao_prog_notio as np where nq.id_question = ? and date(nv.datetime) = nc.from_begin_campaign and nc.id_client = np.id_client and nq.id_question = nc.id_question group by date(nv.datetime)",(id_question,)).fetchall()
    if len(request) > 0:
    #satisfaction moyenne associée à cette question (dans la table nao_votes)
        satisfaction = list(map(lambda x : x[4] , request))
        satisfaction_average = round(sum(satisfaction)/len(satisfaction) , 2)
		
		#satisfaction seuil associée à la question 
        treshold = request[0][5]
        nb_votes = list(map(lambda x : x[2] , request))
        nb_votes_treshold = request[0][3]
		
		#nombre de votes moyens associée à cette question (dansla table nao_votes)
        nb_votes_average = round(sum(nb_votes)/len(nb_votes))
        
        x_votes = abs(nb_votes_average - nb_votes_treshold)
        y_satisfaction = abs(satisfaction_average - treshold)
        
        rating = rate(x_votes , y_satisfaction)
        
        return round(rating , 2)
    
    else:
	#en cas de non vote sur cette question alors rating(id_question) = 0
      return 0


def rating_questions(id_device , id_client , nb_votes_min , id_kpi , duree_campaign):

    #verification de l' etat de la table nao_campaign sur ce device particulier (si froide ?!)
    
    
    request = cur.execute("select id_campaign , from_begin_campaign  from nao_campaign where id_device = ? and id_client = ? order by from_begin_campaign desc limit 1",(id_device , id_client)).fetchone()

    if request == None:
        
        request = cur.execute("select id_question from nao_question_bank where id_kpi = ? order by rate desc limit 1",(id_kpi,)).fetchall()
        begin_campaign = datetime(2016 , 8 , 1).date()
       #cahnger une fois poser sur le serveur remplacer par [begin_campaign = datetime.now().date()]
        id_question = int(request[0][0])
        id_campaign = str(uuid.uuid4().fields[-1])[:4]
        cur.execute('''insert into nao_campaign values(?,?,?,?,?,?)''',(id_campaign , id_device , id_client , id_question , id_kpi , begin_campaign))
        conn.commit()
        print("first campaign in!") 
        
        
    else:
            
            #date de la dernière campagne sur la table nao_campaign
        begin_campaign = parser.parse(request[1]).date() + timedelta(days = 1)
            
        id_campaign = str(uuid.uuid4().fields[-1])[:4]
        #premiere campagne par defaut
    
        
    #dernier jour de votes
        request = cur.execute("select nc.id_campaign , nc.from_begin_campaign , nq.under_threshold , nq.treshold , nc.id_question from nao_campaign as nc , nao_question_bank as nq where nc.id_question = nq.id_question order by from_begin_campaign desc limit 1").fetchall() 
        id_campaign = int(request[0][0])
        last_campaign = parser.parse(request[0][1]).date()
        id_question = request[0][-1]
#        print(id_question)
        #nombre de fois ou la question en cours de sondage est passée sous son seuil de satisfaction
        under_treshold = int(request[0][2])
        treshold = float(request[0][-2])
        
        request = cur.execute("select sum(yes)+sum(neutre)+sum(no) , round((sum(yes) + 0.5*sum(neutre))/(sum(yes) + sum(neutre) + sum(no)) , 2) from nao_votes where date(datetime) = ?",(last_campaign,)).fetchall()
        nb_votes = int(request[0][0])
        satisfaction = float(request[0][1])
        
#        print(nb_votes)
    ##significativité du nombre de vote
        if nb_votes > nb_votes_min and satisfaction < treshold:
#            print("over here!")
            under_treshold = under_treshold + 1
                        
            if under_treshold == 5:
                print("change rating!")
                request = cur.execute("select id_question from nao_question_bank where id_kpi = ?",(id_kpi,)).fetchall()
    #                
                list_id_question = list(map(lambda x : x[0] , request))
                
                    
                for id_questions in list_id_question:
                    #mise a jour des notes de chaaque question dans le kpi
                    question_rate = ratings(id_question)
                    cur.execute("update nao_question_bank set rate = ? where id_question= ? and id_kpi = ?",(question_rate, id_questions , id_kpi))
                    cur.execute("update nao_question_bank set under_threshold = 0 where id_question= ? and id_kpi = ?",(id_questions , id_kpi))
                conn.commit()
                
                request = cur.execute("select id_question from nao_question_bank where id_question not in (select id_question from nao_campaign order by from_begin_campaign desc) and id_kpi =? order by rate desc limit 1",(id_kpi,)).fetchall()
                #sortie du kpi si il n y aplus de questions à sonder en se baser sur le rate max
                if len(request) == 0:
                    pass
                
                else:
                    id_question = request[0][0]
                    begin_campaign = last_campaign + timedelta(days = duree_campaign)
                    
                    id_campaign = id_campaign + 1
                    
                    cur.execute('''insert into nao_campaign values(?,?,?,?,?,?)''',(id_campaign , id_device , id_client , id_question , id_kpi , begin_campaign))
                    conn.commit()
                
            else : 
                
                #mise a jour de la valeur de la variable de temporisation
                under_treshold_new = under_treshold
                cur.execute("update nao_question_bank set under_threshold = ? where id_question= ? and id_kpi = ?",(under_treshold_new , id_question , id_kpi))
                conn.commit()
                
                request = cur.execute("select id_question from nao_question_bank where id_question not in (select id_question from nao_campaign order by from_begin_campaign desc) and id_kpi =? order by rate desc limit 1",(id_kpi,)).fetchall()
                #sortie du kpi si il n y aplus de questions à sonder en se baser sur le rate max
                if len(request) == 0:
                    pass
                else:
                    id_question = request[0][0]
                    begin_campaign = last_campaign + timedelta(days = duree_campaign)
                    
                    id_campaign = id_campaign + 1
                    
                    cur.execute('''insert into nao_campaign values(?,?,?,?,?,?)''',(id_campaign , id_device , id_client , id_question , id_kpi , begin_campaign))
                    conn.commit()
            
                   
        else:
            
            #expedition de la question suivant avec la plus grande note
            request = cur.execute("select id_question from nao_question_bank where id_question not in (select id_question from nao_campaign order by from_begin_campaign desc) and id_kpi =? order by rate desc limit 1",(id_kpi,)).fetchall()
#sortie du kpi si il n y aplus de questions à sonder en se baser sur le rate max
            if len(request) == 0:
                 pass
            else:
                     
                id_question = request[0][0]
                begin_campaign = last_campaign + timedelta(days = duree_campaign)
                
                id_campaign = id_campaign + 1
                
                cur.execute('''insert into nao_campaign values(?,?,?,?,?,?)''',(id_campaign , id_device , id_client , id_question , id_kpi , begin_campaign))
                conn.commit()
            
    
    
#le principe de fonctionnement de rating_question est d envoyer  en sondage (pour un client particulier passé en paramètre) des questions d un kpi par ordre croissant de la note maximum associé à une question 
#en fonction du nombre de votes moyens et satisfaction moyenne comparer respectivement au nombre de votes minimum de ce client et la satisfaction seuil associée à chaque question 


#requte permettant de recupere les indicateurs nécessaires sur un client
request = cur.execute("select nd.id_device , np.id_client , np.nb_votes_treshold  , nk.id_kpi , np.duree_campaign  from nao_device as nd , nao_prog_notio as np , nao_kpi as nk where np.id_client = nd.id_client and nd.id_client = nk.id_client and np.usage_type = 1").fetchall()
print(request) 

id_device = request[0][0]
id_client = request[0][1]
nb_votes_min = request[0][2]
id_kpi = request[0][3]
duree_campaign = request[0][-1] 

print([id_device , id_client , id_kpi , nb_votes_min , duree_campaign])

rating_questions(id_device , id_client , nb_votes_min , 6 , duree_campaign)
