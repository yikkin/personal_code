#INCORPORER DANS LE RAPPORT LES METRICS DE CHECKING DENDOGRAM:
    #https://joernhees.de/blog/2015/08/26/scipy-hierarchical-clustering-and-dendrogram-tutorial/

#coloration des  branches du dendogram
#https://stackoverflow.com/questions/20601398/how-to-color-parts-of-links-in-dendrograms-using-scipy-in-python

# -*- coding: utf-8 -*-
"""
Created on Wed Aug  2 19:24:32 2017

@author: Yongwe Jean-Luc
"""
#importation de modules

import sqlite3 as sql


conn = sql.connect('RH.db')
cur = conn.cursor()

import matplotlib.pyplot as plt


requete = cur.execute("select kpi_name , question from nao_question_rh ").fetchall()


#cette me�thode a �t� pens�e pour pouvoir etre compil� en local ,
#le but recherch� est de permettre � la soci�t� de pouvoir faire de la recommandation � un client qui d�sire
#sonder un ou deux kpis sur la borne prise chez Agora Opinion de fait si il a plus de kpi a exploiter il utilise la borne 
#plus longtemps et potentiellement c est plus de business entrant pour la soci�t�


def key_performance_indicators_clustering(requete , method):

    from stop_words import get_stop_words
    import re
    from nltk.stem.snowball import FrenchStemmer 

    import math
    import pandas as pd
    
    import numpy as np 
    import matplotlib.pyplot as plt
    
    from scipy.cluster.hierarchy import dendrogram, linkage
    
    stop_words = get_stop_words('french')
    stop_words.extend(['Je' , 'A' , 'L' , 'que' ,'votre' ,'la' ,'il' , 's' , 'tout' , '2016' , 'vos' , 'le' , 'vous' , 'Le' ,'la','j','nous'])
        
    def flattenList(S):
        if S == []:
            return S
        if isinstance(S[0], list):
            return flattenList(S[0]) + flattenList(S[1:])
        return S[:1] + flattenList(S[1:])

    def clean_sentence(list_sentence):
        new_list = []
        for sentence in list_sentence:
            cleanSentence = re.sub('\W+',' ', sentence) #retrait des caracteres speciaux
            sent = cleanSentence.split()
            new_sentence = [word for word in sent if word not in stop_words] #retrait des stop_words
            new_list.append(new_sentence) #comptage de l occurence des termes dans une phrase
    
        return new_list
    
    #stemmization function
    #methode de racinisation
    def stemmization(document):
        stemmer = FrenchStemmer()
        resultat =[[stemmer.stem(word) for word in liste_words] for liste_words in document]
        
        return resultat
    
    #methode de filtrage d une liste selon un crit�re
    def filtering(liste , criteria):
        transition = list(filter(lambda x : x[0] == criteria , liste))
        return list(map(lambda x : x[1] , transition))
    
    
    #dictionnaire de mots
    def wordsets(list_documents):
        list_words = []
        index = 0
        wordSet = set(flattenList(list_documents))
        res = list_documents
        for document in res:
            index = index + 1
            worddict_document = dict.fromkeys(wordSet , 0)
            
            for word in document:
                worddict_document[word] += 1
    
            list_words.append(worddict_document)
 
        return list_words
    
    def computeTF(wordDict , bow):
        tfDict = {}
        bowCount = len(bow)
        for word , count in wordDict.items():
            tfDict[word] = count / float(bowCount)
            
        return tfDict



    def TF_documents(list_documents , wordset_list_documents):
    
        list_tfBow = []
        for index_item in range(len(list_documents)):
            worddict_doc = wordset_list_documents[index_item]
            stemdoc =list_documents[index_item]
            tfBow = computeTF(worddict_doc , stemdoc)
            list_tfBow.append(tfBow)
            
        return list_tfBow
    
    #reslt = TF_documents(document_titles)
    def computeIDF(docList):
        idfDict = {}
        N = len(docList)
        
        #counting number of documents that contains a word w
        idfDict = dict.fromkeys(docList[0].keys() , 0)
        for doc in docList:
            for word , val in doc.items():
                if val > 0:
                    idfDict[word] += 1
            
        for word , val in idfDict.items():
            idfDict[word] = math.log(N / float(val))
            
        return idfDict
    
    def give_idfs(wordset_list_documents):
        reslt = wordset_list_documents
        list_doc = []
        for doc in reslt:
            list_doc.append(doc)
        
        return computeIDF(list_doc)
    
        
    def computeTFIDF(tfBow , idfs):
        tfidf = {}
        for word , val in tfBow.items():
            tfidf[word] = val * idfs[word]
            
        return tfidf
    
    
    
    def tfidfBow_document(TF_list_documents , idfss):

        result = []
        for item in TF_list_documents:
            reslt = computeTFIDF(item , idfss)
            result.append(reslt)
        
        return result

    kpi_names = list(set(list(map(lambda x : x[0] , requete))))
    
    list_documents = []
#    list_words = []
    for kpi_name in kpi_names:
        list_questions = filtering(requete , kpi_name) #filtrage de questions par kpi
        cleaned_sentence = clean_sentence(list_questions) #extraction de stopwords
        stem_document = stemmization(cleaned_sentence)
        list_documents.append(flattenList(stem_document)) #resultat de stem_doc
        wordset_list_documents = wordsets(list_documents) #resultat de wordsets
        
        TF_list_documents = TF_documents(list_documents , wordset_list_documents)
        idfss = give_idfs(wordset_list_documents)
        tfidfBow_list_documents = tfidfBow_document(TF_list_documents , idfss)
        
    df = pd.DataFrame(tfidfBow_list_documents)
    df.index = kpi_names
    
    shp = len(df)
    
    ##cosine similarity
    def cosine_similarity(a, b):
        return sum([i*j for i,j in zip(a, b)])/(math.sqrt(sum([i*i for i in a]))* math.sqrt(sum([i*i for i in b])))
    
    def dist_euclidienne(a,b):
        return math.sqrt(sum([(i-j)**2 for i,j in zip(a,b)]))
    
    
    df = df.transpose()
    
    list_similarity = []
    lst = []
    
    for col1 in df.columns:
        doc1 = df[col1]
        for col2 in df.columns:
            doc2 = df[col2]
            list_similarity.append(cosine_similarity(doc1 , doc2))

        lst.append(list_similarity)
        list_similarity = []
        
    
    dft = pd.DataFrame(np.array(lst).reshape(shp,shp) , columns = kpi_names)    
    
    dist_mat = dft
    nums = len(dist_mat)
    color = ['b']*(2*nums - 1)
    color[10] = 'r',
    color[11] = 'y',
    color[12] = 'g',
    linkage_matrix = linkage(dist_mat,method = method ,  metric = 'euclidean')
    print(linkage_matrix)
    link_matrix = linkage(linkage_matrix,method = method ,  metric = 'euclidean')
#    
    plt.figure(figsize= (7 , 7))
    
    plt.subplot(1, 2, 1)
    plt.title("KPI Hierarchical Clustering :" + str(method))
    HAC_dendogram = dendrogram(link_matrix,

               leaf_font_size=12.,
               show_contracted=True,
               truncate_mode='lastp',
               p=10,
               
               labels= kpi_names,
               distance_sort='ascending' , orientation = 'left') 
#    
    
    plt.tick_params(\
                      axis= 'x',          
                         which='both',      
                         bottom='off',      
                         top='off',         
                         labelbottom='off')
    plt.tight_layout()
#    
    return [dist_mat , linkage_matrix]

reslt = key_performance_indicators_clustering(requete , 'average')        
    



from scipy.cluster.hierarchy import cophenet
from scipy.spatial.distance import pdist
from operator import itemgetter
import matplotlib

#commenter tout le code

#fonction de comparaion de l efficacit� des diff�rente m�thodes
performances = []
liste_method = []
methods = ['ward' , 'single' , 'complete' , 'average']
for method in methods:
    print("===================================================")
    reslt = key_performance_indicators_clustering(requete , method)
    coeff_corr , coph_dists = cophenet(reslt[1] , pdist(reslt[0]))
    
    print('cophenet coefficient ',method ,' is :',coeff_corr)
    liste_method.append(method)
    performances.append([method , round(coeff_corr , 2)])

performances = sorted(performances , key = itemgetter(1))

kpiname = list(set(list(map(lambda x : x[0] , requete))))

fig = plt.figure()
coef_performances = list(map(lambda x : x[1] , performances))
method_performances = list(map(lambda x : x[0] , performances))
x = range(len(performances))

plt.title("HAC's methods performances")
plt.plot(x , coef_performances , '-bo')

font = matplotlib.font_manager.FontProperties(family='Tahoma', 
        weight='extra bold', size=11) 

for xy in zip(x , coef_performances):
    plt.annotate(str(round(xy[1], 2)), xy=xy, textcoords='data', fontproperties = font)
plt.xticks(x , method_performances)

#    


