# -*- coding: utf-8 -*-
"""
Created on Thu Sep 21 14:06:24 2017

@author: Utilisateur
"""

import sqlite3 as sql
from dateutil import parser
from datetime import timedelta
conn = sql.connect('db_alg_gpcc.db')
cur = conn.cursor()
import random as rnd

#methode d aplatissement de listes de listes ex : flattenList([[[1,2]] , [4,5]]) = [1,2,4,5]
def flattenList(S):
   if S == []:
       return S
   if isinstance(S[0], list):
       return flattenList(S[0]) + flattenList(S[1:])
   return S[:1] + flattenList(S[1:])
   
   
 
def change_day(day_test , day_week_test):
    
    day_day_test = day_test.isocalendar()[2]
    diff_days = day_day_test + (5 - (day_day_test  - day_week_test))
    
    new_day = day_test + timedelta(days = diff_days)
    return new_day
    

def add_campaign(id_device , id_client , new_recolt_surveys , list_id_question_bis , parsed_last_begin_campaign):
    days_recolt_surveys = flattenList(list(map(lambda z : z[3] , new_recolt_surveys))) 
    set_days_recolt_surveys = list(set(list(map(lambda x : x.date() , days_recolt_surveys))))     

    set_days_recolt_surveys.append(parsed_last_begin_campaign.date()) 

    set_days_recolt_surveys = sorted(set_days_recolt_surveys)

    first_day_survey = set_days_recolt_surveys[0]
    last_day_survey = set_days_recolt_surveys[-1]

    date_range = (last_day_survey - first_day_survey).days
    liste_days = [first_day_survey + timedelta(days = x) for x in range(0 , date_range)] 

    liste_days = [day for day in liste_days if day not in set_days_recolt_surveys]
    

    rnd.shuffle(list_id_question_bis)
    new_set_campaign = [[id_device , id_client , item1 , item2] for item1 , item2 in zip(list_id_question_bis , liste_days)]
    
    return new_set_campaign



def detected_questions(id_device):

#lecture de la dernière campagne de sondage associé à un device
    query = cur.execute("select from_begin_campaign , id_campaign , id_client  from nao_campaign where id_device = ? order by date(from_begin_campaign) desc limit 1 ",(id_device,)).fetchall()
    
	#lecture des questions sondés sur ce device ayant été détectés
	cross_request = cur.execute("select id_question , day , begin_hour , end_hour , id_device from nao_question_pattern where id_device = ?",(id_device,)).fetchall()

    id_client = query[0][2]
    id_campaign = query[0][1]
    last_begin_campaign = query[0][0]
    parsed_last_begin_campaign = parser.parse(last_begin_campaign) 
    new_day_campaign = parsed_last_begin_campaign

    question_begin_end_hour = list(map(lambda y : [y[0] , y[2] , y[3] , y[1] , y[4] , id_client] , cross_request))
    
	#recuperation de toutes les questions ayant été sondés sur ce device
    new_request_bis = cur.execute("select distinct(id_question) from nao_campaign where id_device = ?",(id_device,)).fetchall()
    list_id_question_bis = list(map(lambda x : x[0] , new_request_bis))
    
    
    days_detects = []
    recolt_surveys = []    
    for line in question_begin_end_hour:
    
        id_device = line[4]
        id_client = line[5]
        
		#cran de surete (si deux questions sont detectes sur le meme device le meme jour elles seront poses à une semaine d intervalles
        if line[3] in days_detects:
           day_week_count = days_detects.count(line[3])
           day_campaign = change_day(parsed_last_begin_campaign , line[3]) + timedelta(days = 7 * day_week_count)
           
        else:
            day_campaign = change_day(parsed_last_begin_campaign , line[3])
        days_detects.append(line[3])
		
	#instruction pour etre en mesure de sonder le public-cible de 8h a 18h en dehors du creneau detectes
	#ex id_quetion = 33 detectes de 12h a 15h => 8h a 12h poser question aleatoire dans le id_kpi 3 ; de 12h a 15h poser la question 33 ; de 15h à 18h poser question aléatoire dans id_kpi 3
        
	#dans le cas ou une question n'  a pas de detections alors elle sera reposé de fçon aléatoire durant 24 heures	
		
		if parser.parse(line[1]).hour > 8 and parser.parse(line[2]).hour < 18:
            new_question1 = rnd.choice(list_id_question_bis)
            new_question2 = rnd.choice(list_id_question_bis)
            
            new_begin1 = day_campaign + timedelta(hours = 8)
            new_begin2 = day_campaign + timedelta(hours = parser.parse(line[1]).hour)
            new_begin3 = day_campaign + timedelta(hours = parser.parse(line[2]).hour)
            
            surveys =[[id_device , id_client , new_question1 , new_begin1] , [id_device , id_client , line[0] , new_begin2] , [ id_device , id_client , new_question2 , new_begin3]]
            
            recolt_surveys.append(surveys)
    
            new_recolt_surveys = sum(recolt_surveys , [])
        new_day_campaign = new_day_campaign + timedelta(days = 1)
             
        if parser.parse(line[1]) == 8 :
            new_begin2 = day_campaign + timedelta(hours = parser.parse(line[1]).hour)
            new_begin3 = day_campaign + timedelta(hours = parser.parse(line[2]).hour)
            
            surveys = [[id_device , id_client , line[0] , new_begin1] , [id_device , id_client , new_question1 , new_begin2]]
            
            recolt_surveys.append(surveys)
            new_recolt_surveys = sum(recolt_surveys , [])

    new_campaigns = add_campaign(id_device , id_client , new_recolt_surveys , list_id_question_bis , parsed_last_begin_campaign) + new_recolt_surveys
#envoi de la série de campagne associé au device en parametre sur la table nao_campaign
    for line in new_campaigns:
        id_campaign = id_campaign + 1
        cur.execute('''insert into nao_campaign values(?,?,?,?,?,?)''',(id_campaign , int(line[0]) , int(line[1]) , int(line[2]) , int(line[2]/10) , str(line[3])))
    conn.commit()
    print("committment done!")
       


query = cur.execute("select distinct(id_device) from nao_campaign").fetchall()
print(query)

for item in query:
    detected_questions(item[0])
#condition majeur ecraser reguliere les données de détections  

#il reste la version courte durée












  