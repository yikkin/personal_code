

#importation module
from datetime import datetime
import sqlite3 as sql

from operator import itemgetter

from dateutil import parser
import itertools
#creation de la base de données 
conn = sql.connect('db_alg_gpcc.db')
cur = conn.cursor()


#calcul de la satisfaction courante
def detections(base , treshold):
    from collections import deque
    
   #methode de conversion d un nombre en entier ex : toInt(5.2) = 5
    def toInt(val):
        try:
            return int(val)
        except :
           return None
    
  #methode de aplatissement de listes ex : flattenList([[[1,2]] , [4,5]]) = [1,2,4,5] 
    def flattenList(S):
       if S == []:
           return S
       if isinstance(S[0], list):
           return flattenList(S[0]) + flattenList(S[1:])
       return S[:1] + flattenList(S[1:])

	   #methode somme de liste d entiers ex : tosom([1,2,3]) = 6
    def tosom(val):
        try:
          return sum(val)
        except:
          return val
#methode de transformation en strind ex : toString(5) = '5'
    def toString(sent):
        try:
          return str(sent)
        except:
          return None

#fenetre glissante de somme des signaux oscultés en parallèles
    valGliss = [0.0]*3
    debut = None

    deviceprev = ''
    ind = 0
    for line in base:
        
        index = 0

        
#indicateur du lieu exact courant
        device = line[0]
#indicateur de l heure (jour , heure , min ,sec) au moment du calcul
        dat = line[1]
        
        if device!=deviceprev:

            deviceprev = device
#fenetre de calcul ex : si les votes sur 30 minutes window = 3 => calcul satsifaction sur 2 heures
            window = 3
            cptinit = 0
#fenetre de glissement temporaire des votes jusqu'a l'épuisement d un certain lieu
            deq = [deque(toInt(line[idx]) for _ in range(window)) for idx,_ in enumerate(line) if idx >1 and idx <5]
            valGliss = [tosom(deq[idx-2]) for idx,_ in enumerate(line) if idx >1 and idx<5]

        else:
#action a faire tant qu on est dans la fenetre de calcul
            if cptinit < window:
                cptinit = cptinit + 1
            for idxline , vote in enumerate(line):
                
                if idxline > 1 and idxline <5:
                    idex = idxline-2
                    

                    vote = toInt(vote)
  #extraction de la plus ancienne donnée           
                    out = deq[idex].popleft()
					
#entree de la nouvelle donnée
                    deq[idex].append(vote)
              #reajustment des valeurs globales dans les fenetres des votes (yes , neutre , no)  
                    valGliss[idex] = valGliss[idex] + vote - out

                    index = index + 1
                    
                if cptinit == window:
                    if index == 1:
#incrementation de la somme des votes yes
                        yes = valGliss[idex]

                    if index == 2:
#incrementation de la somme des votes neutre
                        neutre = valGliss[idex]

                    if index == 3:

                        no = valGliss[idex]
     #calcul de la satisfaction a chaque itération             
                        satisfaction =  round((yes + 0.5*neutre)/(yes + neutre + no) , 2)
                        nb_votes = (yes + neutre + no)


                        limit_high = treshold #mettre comme limit le seuil de satisfaction de la question lue
#                        
                        
                        diff_signal_high = limit_high - satisfaction

#entre dans la détection (si la satisfaction courante est inférieure à la satisfaction seuil de la question à condition que 
#qu il ny ait pas de détections en cours)						
                        if satisfaction < limit_high  and  diff_signal_high > 0 and debut == None:
                            
                            debut = dat
                            debut_day = parser.parse(debut).date() #reperage jour du debut de la detection
                            debut_hour = parser.parse(debut).hour #reperage heure du debut de la detection

                        if not (debut is None) and satisfaction > limit_high:
                            ind = ind + 1
                            fin = dat
                            fin_day = parser.parse(fin).date()
                            fin_hour = parser.parse(fin).hour
                            if debut_day == fin_day and debut_hour != fin_hour and ((fin_hour - debut_hour) < 6):

                               yield flattenList([device , debut  , fin  , satisfaction  , nb_votes, parser.parse(dat).date().isocalendar()[2]])
                           
                            debut = None
                          

#methode de calcul d occurence d un item dans une liste ex : occurency([1,1,1,1,2,2,,4,4,5]) = [[1,4],[2,2],[4,2],[5,1]]
def occurency(item_liste):
    liste_occurency = [[x,item_liste.count(x)] for x in set(item_liste)]
    return sorted(liste_occurency)


#methode se nourrissant des sorties de la methode "campaigns" et rendant en sortie l intervalle de detection type sous
# forme [debut_heure , fin_heure , jour_entier]
def frequency_detections(campaign_indicators):
    
    lst_detects = []
    lst_detections = []
    id_devices = campaign_indicators[0]
    begin_campaigns = campaign_indicators[1]
    treshold = campaign_indicators[2]
    
    for id_device , begin_campaign in itertools.zip_longest(id_devices , begin_campaigns):
     #requete d extraction de tous les votes d'une journée de sondge dans la table nao_vote
        query = cur.execute("select device, datetime , yes , neutre , no from nao_votes where device = ? and date(datetime) = ?",(id_device  , begin_campaign)).fetchall()
#sortie des détections associées à ce jour 
        detects = list(detections(query , 0.8))
        lst_detects.append(detects)
        
    lst_detections =sum(lst_detects , [])

    if len(lst_detections) > 0:
#liste des debuts de detections d une question sur toutes les journées de sondage
        begin_vector = list(map(lambda x : parser.parse(x[1]).hour , lst_detections))
		
		#liste des fins de detections d une question sur toutes les journées de sondage
        end_vector = list(map(lambda x : parser.parse(x[2]).hour , lst_detections))
		
		#liste des jours (entier du jour de la semaine) de detections d une question sur toutes les journées de sondage
        days_vector = list(map(lambda x : x[5] , lst_detections))
        
        #liste des durées de detections d une question sur toutes les journées de sondage
        duration_vector = [end_hour - begin_hour for end_hour , begin_hour in zip(end_vector , begin_vector)]

		#l heure de debut de detections  apparaissant le plus
        frequency_begin = occurency(begin_vector)
		
#l heure de fin de detections  apparaissant le plus 
        frequency_end = occurency(end_vector)

#la durée de detections  apparaissant le plus
        frequency_duration = occurency(duration_vector)
 
 #entier jour de la détection apparaissant le plus
        frequency_day = occurency(days_vector)
        
        begin_end_frequency = frequency_begin + frequency_end

        begin_end_max = max(begin_end_frequency)
        duration_max = max(frequency_duration)
        
        day_max = max(frequency_day)
		
	#calcul de la "détection type"
        
        if begin_end_max in frequency_begin:
    
            begin_hour = begin_end_max[0]
            end_hour = begin_end_max[0] + duration_max[0]
            day = day_max[0]
  
        else:
    
            end_hour = begin_end_max[0]
            begin_hour = begin_end_max[0] - duration_max[0]
            day = day_max[0]
       
        return [begin_hour , end_hour , day]      
        
    else:
        pass
 
 
 

 #methode de recuperation toutes les indications de campagnes d une question (les jours où une question est sondée)
#ex id_question = 33 sur l'id_device = 507 et treshold = 0.75 (satisfaction seuil de la question) =>  campaigns(507 , 33 , 0.75) = [[507 , 507] , ['2016-08-01' , 2016-08-10' , 2016-08-23'] , 0.75

def campaigns(id_device , id_question , satisfaction_treshold):
    request = cur.execute("select id_device , id_question ,  from_begin_campaign from nao_campaign where id_question = ? and id_device = ?",(id_question,id_device)).fetchall()
    begin_campaign = list(map(lambda x : x[2] , request))

    devices = list(map(lambda x : x[0] ,request))
    
    return [devices  , begin_campaign , satisfaction_treshold]
    
#campaign = campaigns(507 , 33 , 0.75)
 
#requete pour recuperer les id_devices (où sont sondés des questions) , les id_questions et les satisfactions seuils associées de chaque questions
request = cur.execute("select nc.id_device ,  nc.id_question , nc.from_begin_campaign , nq.treshold from nao_campaign as nc , nao_question_bank as nq where nc.id_question = nq.id_question").fetchall()
#print(request)


lst = []
lst2 = []

#deploiement de la méthode de fréquence de détections ("détection type") sur toutes les questions
#et toutes les campagnes
for item in request:

    campaign = campaigns(item[0] , item[1] , item[3])

    freq = frequency_detections(campaign)

    lst.append([freq , item])
    if freq != None :
        if freq[1] > 17:
             lst2.append([item[0] , item[1] , freq[0] , 17 , freq[2]])
        else:
            lst2.append([item[0] , item[1] , freq[0] , freq[1] , freq[2]])
    else:
        pass
print("==========================================================")
    
survey_detections = list(set(tuple(row) for row in lst2))  
    
    
    
#reuqete pour sortir toutes les questions et tous les devices de la table nao_campaign pour y appliquer a recherche de détection
#request = cur.execute("select id_device ,  id_question , from_begin_campaign  from nao_campaign").fetchall()

#enregistrement des indicateurs de detections de perte de satisfaction dans une table de données "nao_question_pattern"

cur.execute('''create table if not exists nao_question_pattern (id_device integer , id_question integer , begin_hour text , end_hour text , day integer)''')
conn.commit()

for line in survey_detections:
    cur.execute('''insert into nao_question_pattern values (?,?,?,?,?)''' , (int(line[0]) , int(line[1]) , str(line[2])+str(':00') , str(line[3])+str(':00') , int(line[4])))
conn.commit()

print("committment to nao_question_pattern done!")


