# -*- coding: utf-8 -*-
"""
Created on Mon Sep  4 10:24:00 2017

@author: Utilisateur
"""

#importation des modules
#module de connexion à la base de données localement sur le pc
#lors du plug sur la BDD de production à mettre en commentaires 
#et plug la BDD par un connecteur adéquat (voir internet)
import sqlite3 as sql

from datetime import datetime, timedelta
from dateutil import parser
import random as rnd
#import dill
import uuid

#ouverture et connexion à la base de données
conn = sql.connect('dnotio.db')
cur = conn.cursor()

#methode d iteration des questions par aléatoire (random)
def random_questions(id_client , device , id_kpi , duree_campaign):
#verifiaction si la table nao_campaign est "froide" (aucune campagendeja mancé pour ce client sur cette borne)
    request = cur.execute("select id_campaign , to_end_campaign  from nao_campaign where id_device = ? and id_client = ? order by to_end_campaign desc limit 1",(device , id_client)).fetchone()

    if request == None:
        begin_campaign = datetime(2016 , 8 , 1).date()
        # a changer et mettre à la place  [ begin_campaign = datetime.today().date()]
       
    else:
        
        #lancement de la nouvelle serie de campagne à partir de la date de la dernière campagne en cours [lors du relancement du script]
        begin_campaign = parser.parse(request[1]).date() + timedelta(days = 1)
    
#generation de l id campaign à 4 chiffres
    id_campaign = str(uuid.uuid4().fields[-1])[:4]
      
#extraction de la liste des id_questions pour le kpi en exploitation
    query = cur.execute("select id_question  from nao_question_bank where id_kpi = ?",(id_kpi, )).fetchall()

    list_id_question = list(map(lambda x : x[0] , query))
    
#randomization de la liste des id_questions
    rnd.shuffle(list_id_question)
    randomized_list_id_question = list_id_question
    
#envoi de la liste des id_questions dans la table nao_campaigns une à une
    for id_question in randomized_list_id_question:
        
        id_campaign = int(id_campaign) + 1
        end_campaign = begin_campaign + timedelta(days = duree_campaign)
        cur.execute('''insert into nao_campaign values(?,?,?,?,?,?,?)''',(id_campaign , device , id_client , id_question , id_kpi , begin_campaign , end_campaign))

        print("entering campaign from :",begin_campaign , " to :" , end_campaign , " done!")
        begin_campaign = end_campaign + timedelta(days = 1)
    conn.commit()

    print("set of campaign added done!")
        
        

     


#VALIDER
  
                

#visualisation sortie 


query = cur.execute("select nk.id_client , nd.id_device , nk.id_kpi , np.duree_campaign , np.vote_threshold from nao_kpi as nk , nao_device as nd , nao_prog_notio as np where nk.id_client in  (select id_client from nao_prog_notio) and nk.id_client = nd.id_client and nk.id_client = np.id_client and np.id_client = ?",(101,)).fetchall()
print(query)

for item in query:
    print("output :",random_questions(item[0] , item[1] , item[2] , item[3]))
#♥(version done)
