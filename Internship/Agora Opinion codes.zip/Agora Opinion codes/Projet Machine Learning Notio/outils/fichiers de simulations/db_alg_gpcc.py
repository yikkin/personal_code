

import sqlite3 as sql
import pandas as pd


#creation de la base de données 
database_name = 'db_alg_gpcc.db'
conn = sql.connect(database_name)
cur = conn.cursor()

#importation de la base de question format xlsx
#campaign_bank = pd.read_excel('nao_campaign_alg.xlsx' , header = 0)


#campaign_base = list(map(lambda x1 , x2 , x3 , x4 : [x1 , x2 , x3 , x4] , campaign_bank['question'], campaign_bank['device']  , campaign_bank['begin_campaign'] , campaign_bank['end_campaign']))
#
#cur.execute('''create table if not exists nao_campaign_alg (question text, device integer , begin_campaign text , end_campaign text)''')
# 
#for line in campaign_base:
#       cur.execute('''insert into nao_campaign_alg values (?,?,?,?)''', (str(line[0]) , int(line[1]) , str(line[2]) , str(line[3])))
#conn.commit()


#importation de la base de question format xlsx
question_bank = pd.read_excel('programmes RH.xlsx' , header = 0)

#creation de la table question_bank
question_base = list(map(lambda x1 , x2 , x3 , x4 , x5 ,x6 , x7: [x1 , x2 , x3 , x4 , x5,x6, round(x7,2)] ,question_bank['id_question'] , question_bank['question'], question_bank['id_kpi'] , question_bank['kpi_name'] , question_bank['sector'] , question_bank['status'] , question_bank['treshold']))

cur.execute('''create table if not exists nao_question_bank (id_question integer , question text , id_kpi integer , kpi_name text , sector text , rate real ,treshold real, under_threshold integer , status text)''')
 
for line in question_base:
       cur.execute('''insert into nao_question_bank values (?,?,?,?,?,?,?,?,?)''', (int(line[0]) , str(line[1]) , int(line[2]) , str(line[3]) , str(line[4]) , 0 , str(line[6])  , 0 ,str(line[5])))
conn.commit()

#importation de la base de votes format xls (08-2016 / 04-2017) [extract des votes recueillis chez GPCC-Vénissieux]
votes_bank = pd.read_excel('GPCC Venissieux 08-2016-04-2017.xls' , header = 0)

#creation de la table simulation votes
cur.execute('''create table if not exists nao_votes (device integer , datetime text , yes integer , neutre integer , no integer)''')

simulation_votes = list(map(lambda x1 , x2 , x3 , x4 , x5 : [x1 , x2 , x3 ,x4 , x5] , votes_bank['id_device'] , votes_bank['utc_datetime'] , votes_bank['yes'] , votes_bank['neutre'] , votes_bank['no']))

for line in simulation_votes:
           cur.execute('''insert into nao_votes values (?,?,?,?,?)''', (int(line[0]) , str(line[1]) , int(line[2]) , int(line[3]) , int(line[4])))
conn.commit()

cur.execute('''create table if not exists nao_device (id_client integer , id_device integer)''')
conn.commit()

cur.execute('''create table if not exists nao_prog_notio (id_client integer ,nb_votes_treshold integer , duree_campaign integer , profil integer  , usage_type integer)''')
conn.commit()

cur.execute('''create table if not exists nao_kpi (id_client integer , id_kpi integer , kpi_name text)''')
conn.commit()


cur.execute('''create table if not exists nao_campaign (id_campaign integer , id_device integer , id_client integer , id_question integer , id_kpi integer , from_begin_campaign text)''')
conn.commit()


cur.execute('''create table if not exists nao_satisfaction (id_device integer , id_client integer , id_question integer , datetime text , satisfaction real)''')
conn.commit()