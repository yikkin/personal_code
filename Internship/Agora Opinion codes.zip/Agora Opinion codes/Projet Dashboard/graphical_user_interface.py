# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 11:55:03 2017

@author: Utilisateur
"""
#A TRANSFORMER EN .EXE (Valider par CE)



#importation des modules
import tkinter as tk
import pandas as pd
from tkinter import filedialog
 
from datetime import datetime

import matplotlib.pyplot as plt
#import seaborn as sns
import matplotlib

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg

#ajouter version daily tous les jours de votes
#nombre d alertes 4 ieme figure
#et checking sur le meme graphe (si possible)
#fonctions preliminaires
def aggregate_time(dataframe , colonne_target , colonne_time):
    list_sum = []
    set_time = sorted(list(set(dataframe[colonne_time])))
    for time in set_time:
        res = dataframe[dataframe[colonne_time] == time]
        aggregate_sum = sum(res[colonne_target])
        list_sum.append(aggregate_sum)
        
    return list_sum






#methode d ajout des noms des jours de la semaine
def name_day(df_column):
     lst_column = df_column
     output_names = []
     for item in lst_column:
         if item == 1:
             output_names.append('Monday')
         if item == 2:
             output_names.append('Tuesday')
         if item == 3:
             output_names.append('Wednesday')
         if item == 4:
             output_names.append('Thursday')
         if item == 5:
             output_names.append('Friday')
         if item == 6:
             output_names.append('Saturday')
         if item == 7:
             output_names.append('Sunday')
    
     return output_names

def create_timeline(dataframe , col_time , intervalle):
    df_time = dataframe[col_time]
    if intervalle == 'day':
         time_space = list(map(lambda x : x.strftime('%Y-%m-%d') , df_time))
         time = time_space
    if intervalle == 'week':
        time_space = list(map(lambda x : datetime.strptime(x, '%Y-%m-%d').date().isocalendar()[1] , df_time))
        time = time_space
    if intervalle == 'month':
        time_space = list(map(lambda x : x.strftime('%Y-%m') , df_time))
        time = time_space
    if intervalle == 'hour':
        time_space =  list(map(lambda x : x.hour , df_time))
        time = time_space
    
    dataframe[intervalle] = time
    
    return dataframe


def affluence(dataframe , intervalle):
    return aggregate_time(dataframe , 'total vote' , intervalle)
    
    
def moyenne(liste1, liste2 ,liste3):
   moy = list(map(lambda x,y,z : (x + 0.5*y)/(x+y+z) , liste1,liste2,liste3))
    
   return moy

def satisfaction(dataframe , intervalle):
    yes = aggregate_time(dataframe , 'yes', intervalle)
    neutre = aggregate_time(dataframe , 'neutre', intervalle)
    no = aggregate_time(dataframe , 'no', intervalle)
    
    satisfaction = moyenne(yes , neutre , no)
    
    return satisfaction
    


def graphical_vizualisation_month(filename):
    df = pd.read_excel(filename , header = 0)
    create_timeline(df , "utc_datetime" , "month")
    create_timeline(df , "utc_datetime" , "day")

    lieu = list(set(df["lieu_exact"].tolist()))
    
    choice = tk.StringVar()
    choice.set(lieu[0])
    frame = tk.Tk()
   #instruction de creation du dop-down menu
    opt_mn1 = tk.OptionMenu(frame , choice , *lieu)
    opt_mn1.pack()
    
    
    lbl = tk.Label(frame, text="EVOLUTION")
	#taille de la fenetre graphique
    fig = plt.figure(figsize = (20,10))
	
	#placement des differents graphiques
    ax = fig.add_subplot(221)
    ax2 = fig.add_subplot(223)
    ax3 = fig.add_subplot(222)
    ax4 = fig.add_subplot(224)
    
    canvas = FigureCanvasTkAgg(fig, master=frame)
    
    
#boitier d options sur les graphiques (bouton d enregistrement) 
    toolbar = NavigationToolbar2TkAgg(canvas, frame)
    def change(*args):
#instruction permettant d effacer le contenu d une fenetre graphique lorsque l on passe
#d un lieu_exact à un autre
        ax.clear()
        ax2.clear()
        ax3.clear()
        ax4.clear()
        
        df_lieu = df[df["lieu_exact"] == choice.get()]
        choosen_intervalle = sorted(list(set(df_lieu["month"].tolist())))
        satisfaction_lieu_day = satisfaction(df_lieu , "day")
        
        satisfaction_lieu = satisfaction(df_lieu , "month")

        affluence_lieu = affluence(df_lieu, "month")

        x = range(len(satisfaction_lieu))
        x1 = range(len(satisfaction_lieu_day))
        
#propriétés fontsize des textes
        font = matplotlib.font_manager.FontProperties(family='Tahoma', 
        weight='extra bold', size=10) 
  #fonction d affichage de satisfaction en pourcentage sur le graphique      
        def pct(x): return "{}%".format(int(x*100))
        
        pct_satisfaction = [pct(item) for item in [0,0.2,0.4,0.6,0.8,1]]
        
        average_satisfaction = [round(sum(satisfaction_lieu)/ len(satisfaction_lieu) , 2) for item in satisfaction_lieu]
#satisfaction par mois (un point = une satisfaction aggregé mois)    
        plt.subplot(2,2,1)
        plt.title("Satisfaction evolution "+str(choice.get()))
        plt.plot(x,satisfaction_lieu ,"royalblue" , label = "satisfaction" )
        plt.plot(x , average_satisfaction , "purple" , label = "average satisfaction monthly: " + str(average_satisfaction[0]*100)+'%')
        plt.ylim(0,1)
        plt.yticks([0,0.2,0.4,0.6,0.8,1] , pct_satisfaction)
        plt.grid(axis = 'y')
        plt.legend()

    #instruction d annotation du graphique    
        for xy in zip(x , satisfaction_lieu):
            ax.annotate(str(round(xy[1] *100 , 2))+'%', xy= (xy[0] - 0.1 , xy[1]+0.025), textcoords='data',fontproperties = font)

        plt.xticks(x, choosen_intervalle)
#traffic par mois (nombre de votes) 
        plt.subplot(2,2,3)
        plt.title("Traffic evolution "+str(choice.get()))
        plt.bar(x,affluence_lieu , color = "royalblue")
    
        for xy in zip(x , affluence_lieu):
            ax2.annotate(str(xy[1]), xy=(xy[0] - 0.2 , xy[1]+50), textcoords='data' , fontproperties = font)

        plt.xticks(x, choosen_intervalle)
        plt.grid(axis = 'y')
        
#resume en camenbert des votes (yes , neutre , no)      
        plt.subplot(2,2,2)
        nb_vote_yes = sum(aggregate_time(df_lieu , "yes" , "month"))
        nb_vote_neutre = sum(aggregate_time(df_lieu , "neutre" , "month"))
        nb_vote_no = sum(aggregate_time(df_lieu , "no" , "month"))
        
        labels = ['YES : '+str(nb_vote_yes)+ ' votes', 'NEUTRE : '+str(nb_vote_neutre)+' votes', 'NO : '+str(nb_vote_no)+' votes']
        sizes = [nb_vote_yes , nb_vote_neutre , nb_vote_no]
        colors = ['green' , 'yellow' , 'red']
        explode = (0.1, 0, 0)
        
        plt.title("Satisfaction globale")
        plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct = '%1.1f%%' , shadow=True, startangle=140)
        plt.axis('equal')
        
#graphique d evolution de la satisfaction sur la durée de l etude (un point = une satisfaction jour)        
        plt.subplot(2,2,4)
        plt.title("Satisfaction evolution day to day "+str(choice.get()))
        average_satisfaction_lieu_day = [round(sum(satisfaction_lieu_day)/ len(satisfaction_lieu_day) , 2) for item in satisfaction_lieu_day]
        
        plt.plot(x1,satisfaction_lieu_day ,"-g" , label = "satisfaction days")
        plt.plot(x1 , average_satisfaction_lieu_day , "purple" , label = "average satisfaction monthly : " + str(average_satisfaction_lieu_day[0]*100)+'%')
        plt.ylim(0,1)
        pct_satisfaction = [pct(item) for item in [0,0.2,0.4,0.6,0.8,1]]
        plt.yticks([0,0.2,0.4,0.6,0.8,1] , pct_satisfaction)
        plt.grid(axis = 'y')
        plt.legend()
        lbl.pack()
        canvas._tkcanvas.pack()
        canvas.show()
        
    choice.trace("w" , change)
        
    frame.mainloop()

  
    
    
    
def graphical_vizualisation_week(filename):
    df = pd.read_excel(filename , header = 0)
    create_timeline(df , "utc_datetime" , "day")

    create_timeline(df , "day" ,"week")
    df["day week"] = list(map(lambda x : datetime.strptime(x , '%Y-%m-%d').isoweekday(),df["day"]))
    day_week = list(set(df["day week"].tolist()))
    lieu = list(set(df["lieu_exact"].tolist()))
    name_day_week = name_day(day_week)
    frame = tk.Tk()
    
    choice = tk.StringVar()
    choice.set(lieu[0])
      #instruction de creation du dop-down menu
    opt_mn1 = tk.OptionMenu(frame , choice , *lieu)
    opt_mn1.pack()

    lbl = tk.Label(frame, text="WEEKLY EVOLUTION")
	
	#taille de la fenetre graphique
    fig = plt.figure(figsize = (15 , 15))
	
	#placement des differents graphiques
    ax = fig.add_subplot(221)
    ax2 = fig.add_subplot(223)
    ax3 = fig.add_subplot(222)

    ax4 = fig.add_subplot(224)
     
    canvas = FigureCanvasTkAgg(fig, master=frame)

    #boitier graphique d enregistrement de votes
    toolbar = NavigationToolbar2TkAgg(canvas, frame)

    
    def change(*args):
#instruction d effacer une fenetre graphique lorsqu on passe d un lieu_exact à l autre
        ax.clear()
        ax2.clear()
        ax3.clear()
        ax4.clear()
        
#		  ax4.clear()
        
        df_lieu = df[df["lieu_exact"] == choice.get()]
        satisfaction_lieu = satisfaction(df_lieu , "day week")

        affluence_lieu = affluence(df_lieu , "day week")
        alerting_lieu = aggregate_time(df_lieu , "alert" , "day week")

        x = range(len(satisfaction_lieu))
        x1 = range(len(alerting_lieu))
        
    #propriétés fontsize des textes
        font = matplotlib.font_manager.FontProperties(family='Tahoma', 
        weight='extra bold', size=10) 
   #fonction d affichage des pourcentage sur le graphique     
        def pct(x): return "{}%".format(int(x*100))
        pct_satisfaction = [pct(item) for item in [0,0.2,0.4,0.6,0.8,1]]
        average_satisfaction = [round(sum(satisfaction_lieu)/len(satisfaction_lieu),2) for item in satisfaction_lieu]
        
#satisfaction semaine (un point toutes data aggreges sur ce jour)        
        plt.subplot(2,2,1)
        plt.title("Satisfaction evolution "+str(choice.get()))
        plt.plot(x,satisfaction_lieu ,"royalblue" , label = "satisfaction")
        plt.plot(x , average_satisfaction ,"purple" ,  label = "average satisfaction weekly : "+str(average_satisfaction[0]*100)+'%')
        plt.ylim(0,1)
        plt.yticks([0,0.2,0.4,0.6,0.8,1] , pct_satisfaction)
        plt.grid(axis = 'y')
        plt.legend()
#instruction d annotation du graphique
        for xy in zip(x , satisfaction_lieu):
            ax.annotate(str(round(xy[1] *100 , 2))+'%', xy= (xy[0] - 0.1 , xy[1]+ 0.025), textcoords='data' , fontproperties = font)

        plt.xticks(x, name_day_week)
    
#traffic semaine (un point toutes data aggreges sur ce jour)  [nombre de votes]
        plt.subplot(2,2,3)
        plt.title("Traffic evolution "+str(choice.get()))
        plt.bar(x,affluence_lieu , color = "royalblue")
        plt.ylim(0 , 1.1 * max(affluence_lieu))
        
        name_day_week2 = ['Monday' , 'Tuesday' , 'Wed.','Thursday' , 'Friday' , 'Saturday' , 'Sunday']
        index = 0
        for xy in zip(x , affluence_lieu):
            
            ax2.annotate(str(xy[1]), xy=(xy[0] - 0.2 , xy[1]+50), textcoords='data',fontproperties = font)
            index = index + 1
        plt.xticks(x, name_day_week2)
        plt.grid(axis = 'y')
        
#camenbert des donnees resumes
        plt.subplot(2,2,2)
        nb_vote_yes = sum(aggregate_time(df_lieu , "yes" , "day week"))
        nb_vote_neutre = sum(aggregate_time(df_lieu , "neutre" , "day week"))
        nb_vote_no = sum(aggregate_time(df_lieu , "no" , "day week"))

        labels = ['YES : '+str(nb_vote_yes)+ ' votes', 'NEUTRE : '+str(nb_vote_neutre)+' votes', 'NO : '+str(nb_vote_no)+' votes']
        sizes = [nb_vote_yes , nb_vote_neutre , nb_vote_no]
        colors = ['green' , 'yellow' , 'red']
        explode = (0.1, 0, 0)
        
        plt.title("Satisfaction globale")
        plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct = '%1.1f%%' , shadow=True, startangle=140)
        plt.axis('equal')

#evolution des alertes dans un semaines type		  
        plt.subplot(2,2,4)
        plt.title("Alerting "+str(choice.get()))
        plt.plot(x1 , alerting_lieu , color = "firebrick" , label = "alerting")
        plt.ylim(0 , 1.1 * max(alerting_lieu))
        x = range(len(alerting_lieu))
        name_day_week2 = ['Monday' , 'Tuesday' , 'Wed.','Thursday' , 'Friday' , 'Saturday' , 'Sunday']
        name_day_week_alert = name_day_week[0:len(x)]
        plt.xticks(x ,name_day_week_alert)
        plt.grid(axis = 'y')
        plt.legend()
        for xy in zip(x1 , alerting_lieu):
            ax4.annotate(str(xy[1]), xy= (xy[0] - 0.1 , xy[1]+0.4) , textcoords='data',fontproperties = font)

        plt.xticks(x, name_day_week_alert)

		
		
		 
        lbl.pack()
        canvas._tkcanvas.pack()
        canvas.show()
    choice.trace("w" , change)
    
    frame.mainloop() 
    
    
    
    
def graphical_vizualisation_day(filename):
    df = pd.read_excel(filename , header = 0)
    create_timeline(df , "utc_datetime" , "hour")
    create_timeline(df , "utc_datetime" , "day")

    
    lieu = list(set(df["lieu_exact"].tolist()))
    
    choice = tk.StringVar()
    choice.set(lieu[0])
    frame = tk.Tk()
      #instruction de creation du dop-down menu
    opt_mn1 = tk.OptionMenu(frame , choice , *lieu)
    opt_mn1.pack()
    
    
    lbl = tk.Label(frame, text="EVOLUTION")
	
	#taille de la fenetre graphique
    fig = plt.figure(figsize = (20,10))
	
	#instruction d ecart entre les graphiques
    fig.subplots_adjust(hspace=.5)
#placement des graphes
    ax = fig.add_subplot(221)
    ax2 = fig.add_subplot(223)
    ax3 = fig.add_subplot(222)
    ax4 = fig.add_subplot(224)
    
    canvas = FigureCanvasTkAgg(fig, master=frame)
    
    
 #boitier d enregistrement des graphiques   
    toolbar = NavigationToolbar2TkAgg(canvas, frame)
    def change(*args):
#instruction d effacement d une fenetre graphique lors du passage d une fenetre graphique à une autre
        ax.clear()
        ax2.clear()
        ax3.clear()
        ax4.clear()
        
        df_lieu = df[df["lieu_exact"] == choice.get()]

        satisfaction_lieu = satisfaction(df_lieu , "hour")

        affluence_lieu = affluence(df_lieu, "hour")
        alerting_lieu = aggregate_time(df_lieu , "alert" , "hour")

        x = range(len(satisfaction_lieu))
        x1 = range(len(alerting_lieu))
        
#propriétés du texte
        font = matplotlib.font_manager.FontProperties(family='Tahoma', 
        weight='extra bold', size=10) 
       #fonction d affichage du pourcentage sur le graphique
        def pct(x): return "{}%".format(int(x*100))
        average_satisfaction = [round(sum(satisfaction_lieu)/len(satisfaction_lieu) , 2) for item in satisfaction_lieu]
        
#evolution de la satisfaction heure
        plt.subplot(2,2,1)
        plt.title("Satisfaction evolution "+str(choice.get()))
        plt.plot(x,satisfaction_lieu ,"royalblue" , label = "satisfaction")
        plt.plot(x , average_satisfaction , "purple" , label = "average satisfaction daily :"+str(average_satisfaction[0]*100)+'%')
        pct_satisfaction = [pct(item) for item in [0.2 ,0.4,0.6,0.8,1]]
        plt.ylim(0,1)
        plt.xticks(x , x)
        plt.yticks([0.2 ,0.4,0.6,0.8,1]  , pct_satisfaction)
        plt.grid(axis = 'y')
        plt.xlabel('hours' , fontsize = 12)
        plt.legend()

#nombre de votes heures
        plt.subplot(2,2,3)
        plt.title("Traffic evolution "+str(choice.get()))
        plt.bar(x,affluence_lieu , color = "royalblue")
        plt.grid(axis = 'y')
        plt.xticks(x , x)
        plt.xlabel('hours' , fontsize = 12)

#camenbert dde resume des donnees     
        plt.subplot(2,2,2)
        nb_vote_yes = sum(aggregate_time(df_lieu , "yes" , "hour"))
        nb_vote_neutre = sum(aggregate_time(df_lieu , "neutre" , "hour"))
        nb_vote_no = sum(aggregate_time(df_lieu , "no" , "hour"))
        
        labels = ['YES : '+str(nb_vote_yes)+ ' votes', 'NEUTRE : '+str(nb_vote_neutre)+' votes', 'NO : '+str(nb_vote_no)+' votes']
        sizes = [nb_vote_yes , nb_vote_neutre , nb_vote_no]
        colors = ['green' , 'yellow' , 'red']
        explode = (0.1, 0, 0)
        
        plt.title("Satisfaction globale")
        plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct = '%1.1f%%' , shadow=True, startangle=140)
        plt.axis('equal')
        
 #evolution de l alerting - jour       
        plt.subplot(2,2,4)
        plt.title("Alerting "+str(choice.get()))
        plt.plot(x1,alerting_lieu ,"firebrick" , label = "alerting")
        plt.grid(axis = 'y')
        plt.xticks(x , x)
        plt.xlabel('hours' , fontsize = 12)
        plt.legend()

       
        lbl.pack()
        canvas._tkcanvas.pack()
        canvas.show()
        
    choice.trace("w" , change)
        
    frame.mainloop()
          

#methode d ouverture de directory  fichier
def open_file():
    
    global filename 
    filename = filedialog.askopenfilename()
    filename_var.set(filename)
    dframe = pd.read_excel(filename , header = 0)
    return dframe

if __name__ == "__main__":
    frame = tk.Tk()
    
    frame.geometry("600x600")
    frame.title("Graphical User Interface")

    frame.iconbitmap("logo2017.ico")
    
    filename = ''
    
    filename_var = tk.StringVar()
#bouton d importation de du fichier à analyser sous format .xls ou .xlsx
    button1 = tk.Button(frame , text = "Import file" , command = lambda : open_file())
    button1.place(relx = 0.5 , rely = 0.1 , anchor = tk.CENTER)
    
#boutons d analyse des donnees aggreges

#bouton d analyse des données sous formt "semaine type"
    button2 = tk.Button(frame , text = "Weekly based analysis" , command = lambda : graphical_vizualisation_week(filename_var.get()))
    button2.place(relx = 0.5 , rely = 0.3 , anchor = tk.CENTER)
    
#bouton d analyse des données sous format mensuelle
    button2 = tk.Button(frame , text = "Monthly based analysis" , command = lambda : graphical_vizualisation_month(filename_var.get()))
    button2.place(relx = 0.5 , rely = 0.5 , anchor = tk.CENTER)

#bouton d analyse des données sous format "journée type"  
    button2 = tk.Button(frame , text = "Daily based analysis" , command = lambda : graphical_vizualisation_day(filename_var.get()))
    button2.place(relx = 0.5 , rely = 0.7 , anchor = tk.CENTER)
    
  #  button2 = tk.Button(frame , text = "In Depth analysis" , command = lambda : graphical_vizualisation_detailled(filename_var.get()))
  #  button2.place(relx = 0.5 , rely = 0.9 , anchor = tk.CENTER)
    
    
    frame.mainloop()










    
    
    