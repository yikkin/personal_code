# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 17:53:48 2017

@author: Utilisateur
"""

#importation de modules
from datetime import datetime , timedelta
import random as rnd

from dateutil import parser
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

def create_timeline(dataframe , col_time , intervalle):
    df_time = dataframe[col_time]
    if intervalle == 'day':
         time_space = list(map(lambda x : x.strftime('%Y-%m-%d') , df_time))
         time = time_space
    if intervalle == 'week':
        time_space = list(map(lambda x : datetime.strptime(x, '%Y-%m-%d').date().isocalendar()[1] , df_time))
        time = time_space
    if intervalle == 'month':
        time_space = list(map(lambda x : x.strftime('%Y-%m') , df_time))
        time = time_space
    if intervalle == 'hour':
        time_space =  list(map(lambda x : x.hour , df_time))
        time = time_space
   
    dataframe[intervalle] = time
    
def aggregate_dataframe(dataframe , colonne_target):
    list_dataframe = []
    modalities = list(set(dataframe[colonne_target]))
    for mod in modalities:
        df = dataframe[dataframe[colonne_target] == mod]
        list_dataframe.append(df)
        
    return list_dataframe



#================================================================================================================================#
#veritable application commence ici

#fonction de trie (reperage temps de reaction à une alerte)
def tri_alerting_badging(sample):

    #suppression check en meme temps que alerte 
    
#principe : une alerte un check au minimum
#une alerte pas check une autre alerte un check (possibilité)
    for item in sample:
        if item[1] == item[2] and item[2] == 1:
            item[2] = 0
           
    alerting = list(map(lambda x : x[1] , sample))
    checking = list(map(lambda x : x[2] , sample))
    time = list(map(lambda x : x[0] , sample))
    
    device = sample[0][3]
    aire = sample[0][4]
    section = sample[0][5]
    lieu_exact = sample[0][6]

#ensemble des alertes
    index_alert = [index  for index , valeur in enumerate(alerting) if valeur == 1]
    index_check = [index  for index , valeur in enumerate(checking) if valeur == 1]
    
    #ensemble des checks apres une alerte
    index_check_checked = [item2 for item2 , item1 in zip(index_check , index_alert) if item2 > item1]
    
    lst2 = []
    for item1 in index_check_checked:
        lst1 = []
        for item2 in index_alert:
            if item2 < item1:
                lst1.append(item1 - item2)
                imd = item2
    
        lst2.append([lst1[-1] , item1 , imd])
   
#alerte ayant genere une reaction     
    part3_lst2 = list(map(lambda x : x[2] , lst2))
    
    index_warn = list(map(lambda x : x[2] , lst2))
    index_act = list(map(lambda x : x[1] , lst2))

#temps de reaction alerte - check
    diff_time = [int((time[item2] - time[item1]).seconds/60) for item1 , item2 in zip(index_warn, index_act)]
    

    lst = []
    index = 0

    for item in index_alert:
        
        if item in part3_lst2:
       #ligne a transcrire en cas de reactio na une alerte    
           lst.append([item , int(diff_time[index]) , time[item] , timedelta(minutes = diff_time[index]) + time[item]])
           index = index + 1
           
        else:
		#ligne a transcrire en cas de non reaction a une alerte
           lst.append([item , None , time[item] , None])
    
    liste = list(map(lambda x1 : [device , aire, section , lieu_exact ,  x1[2] , x1[3] , x1[1]] , lst))
    return liste


#reslt = tri_alerting_badging(resultats)

#transformation des resultats en dataframe
#dataframe = pd.DataFrame(reslt , columns = ['id_device' , 'aire' , 'section' ,'lieu_exact', 'alerting' , 'checking' , 'time reaction (in minute)'])
#
#dataframe.to_excel('reaction time alert-badging.xls')
#print(" new excel in!")



#fonction de visualisation graphiques des temps de reaction selon seuils
#vector_seuil = [2, 10]

#vector_reaction_time = dataframe[dataframe["time reaction (in minute)"].notnull()]["time reaction (in minute)"]




def barplot_seuil(filename):
    
    dataframe = pd.read_excel(filename , header = 0)
    vector_seuil = [2, 10]
    
    lieu_exacts = list(set(dataframe["lieu_exact"].tolist()))
    
    for lieu in lieu_exacts:
    
        df = dataframe[dataframe["lieu_exact"] == lieu]
        vector_reaction_time = df[df["time reaction (in minute)"].notnull()]["time reaction (in minute)"]
    
        seuil1 = vector_seuil[0]
        seuil2 = vector_seuil[1]
       
        data1 = sum([1 for item in vector_reaction_time if item < seuil1])
        data2 = sum([1 for item in vector_reaction_time if item > seuil1 and item < seuil2])
        data3 = sum([1 for item in vector_reaction_time if  item > seuil2])
       
        data = [data1 , data2 , data3]
        
        font = matplotlib.font_manager.FontProperties(family='Tahoma', 
            weight='extra bold', size=15) 
        x = range(len(data))
        plt.title("reaction time : "+str(lieu))
        plt.bar(x  , data , color = 'deepskyblue' ,  label = 'number of reaction per time category')
    
        for xy in zip(x , data):
            plt.annotate(str(xy[1]), xy=(xy[0] , xy[1] + 0.5), textcoords='data' , fontproperties = font)
    
        plt.ylim(0 , 1.1*max(data))
        
        maxy = max(data)
        quotient = int(maxy / 5)
        ordonnees = [5 * item for item in range((quotient + 2))]
        plt.yticks(ordonnees , ordonnees)
        plt.xticks([0, 1, 2] , [' < 2 minutes' , ' < 10 minutes' , ' > 10 minutes'])
        plt.tick_params(labelsize = 13)
        plt.grid(axis = 'y')
        plt.legend(bbox_to_anchor=(1.05, 1), loc= 3, borderaxespad=0.)
    
        plt.show()
        #instruction pour enregistrer la sortie graphique dans l'arborescence courant
        plt.savefig(str(lieu)+'.png')

    

def reaction_time(filename):

#transformation du fichier excel en dataframe
    dataframe = pd.read_excel(filename , header = 0)
    
    create_timeline(dataframe , "utc_datetime" ,"day")
    #aggregation des dataframes par jours
    temp = aggregate_dataframe(dataframe , "day")
    
    resultats = []
    for dframe in temp:
        #aggregations des dataframes par lieux
        dframe_lieux = aggregate_dataframe(dframe , "lieu_exact")
        for lieu_exact in dframe_lieux:
    
        	#transformation des  timestamp au format datetime
            datetime1 = list(map(lambda x : datetime.timestamp(x) , lieu_exact["utc_datetime"].tolist()))
            utc_datetime = list(map(lambda x : datetime.fromtimestamp(x) , datetime1))
            
        	#recuperation des colonnes de données qui nous interessent
            base = list(map(lambda x1 , x2 , x3 , x4 , x5 , x6 , x7 : [x1 , x2 , x3 , x4 , x5 , x6 , x7] , utc_datetime , lieu_exact['alert'].tolist() , lieu_exact['check'].tolist() , lieu_exact['id_device'].tolist() ,lieu_exact['aire'].tolist() , lieu_exact['section'].tolist() , lieu_exact['lieu_exact'].tolist() ))
            
            reslt = tri_alerting_badging(base)
            resultats.append(reslt)

    reslt2 = sum(resultats , [])

#mise en forme du resultat sous forme de dataframe
    dataframe2 = pd.DataFrame(reslt2 , columns = ['id_device' , 'aire' , 'section' ,'lieu_exact', 'alerting' , 'checking' , 'time reaction (in minute)'])
    new_dataframe = dataframe2.sort_values("id_device")


#export des resultats dans l arborescence courante du resultat au format excel '.xls'
 
    new_dataframe.to_excel('reaction time alert-badging.xls')  
    print("new excel in!")
    
reaction_time("Vinci - Portugal Airport du 01-01-2017 au 15-09-2017.xls")

filename1 ="Vinci - Portugal Airport du 01-01-2017 au 15-09-2017.xls" 
filename2 =  "reaction time alert-badging.xls"   

#sortie graphique des temps de reaction en alerting et badging 
barplot_seuil(filename2)



        
        
        
        
        
        
        
        
        
















