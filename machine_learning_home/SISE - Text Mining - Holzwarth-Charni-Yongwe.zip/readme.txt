ApplicationRShiny.zip
	Application shiny incluant le corpus documentaire dans le r�pertoire data/original

Corpus documentaire.zip
	Corpus documentaire des offres d'emplois (est d�j� inclus dans l'application R Shiny)

Rapport Textmining Holzwarth-Charni-Yongwe.pdf
	Notre rapport

Rapport TextMining sources latex.zip
	Les sources latex de notre rapport